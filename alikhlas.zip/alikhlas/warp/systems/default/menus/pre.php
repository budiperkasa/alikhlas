<?php


/*
	Class: WarpMenuPre
		Menu base class
*/
class WarpMenuPre extends WarpMenu {

	
	/*
		Function: process
			
		Returns:
			Xml Object
	*/	
	function process(&$module, &$xmlobj) {
		return $xmlobj;
	}

}