<?php


// no direct access
defined('_JEXEC') or die('Restricted access');
?>

<p>
	<?php echo $this->escape($this->error); ?>
</p>