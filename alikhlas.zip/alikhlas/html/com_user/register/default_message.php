<?php


// no direct access
defined('_JEXEC') or die('Restricted access');
?>

<h2>
	<?php echo $this->message->title ; ?>
</h2>

<p>
	<?php echo  $this->message->text ; ?>
</p>
