<?php


// no direct access
defined('_JEXEC') or die('Restricted access');

?>

Changelog
------------

1.5.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note