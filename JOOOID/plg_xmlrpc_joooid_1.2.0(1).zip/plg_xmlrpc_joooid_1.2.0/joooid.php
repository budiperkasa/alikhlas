<?php
/**
 * @version	$Id: joooid.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package	Joomla
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license	GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class plgXMLRPCJoooid extends JPlugin
{
	function plgXMLRPCJoooid(&$subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage( '', JPATH_ADMINISTRATOR );
	}

	/**
	* @return array An array of associative arrays defining the available methods
	*/
	function onGetWebServices()
	{
		global $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		return array
		(	
				'joooid.getUserInfo' => array(
				'function' => 'plgXMLRPCJoooidServices::getUserInfo',
				'docstring' => JText::_('Returns information about an author in the system.'),
				'signature' => array(array($xmlrpcStruct, $xmlrpcString, $xmlrpcString, $xmlrpcString))
			),
				'joooid.getUsersBlogs' => array(
				'function' => 'plgXMLRPCJoooidServices::getUserBlogs',
				'docstring' => JText::_('Returns a list of weblogs to which an author has posting privileges.'),
				'signature' => array(array($xmlrpcArray, $xmlrpcString, $xmlrpcString, $xmlrpcString ))
			),
				'joooid.uploadFile' => array(
				'function' => 'plgXMLRPCJoooidServices::uploadFile',
				'docstring' => JText::_('Uploads a file in the specified directory.'),
				'signature' => array(array($xmlrpcString,$xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcStruct))
			),
				'joooid.uploadImage' => array(
				'function' => 'plgXMLRPCJoooidServices::uploadImage',
				'docstring' => JText::_('Uploads an image in the specified directory.'),
				'signature' => array(array($xmlrpcString,$xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcStruct))
			),
				'joooid.newPost' => array(
				'function' => 'plgXMLRPCJoooidServices::newPost',
				'docstring' => JText::_('Creates a new post, and optionally publishes it in frontpage.'),
				'signature' => array(array($xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcInt, $xmlrpcInt, $xmlrpcBoolean))
			),
				'joooid.editPost' => array(
				'function' => 'plgXMLRPCJoooidServices::editPost',
				'docstring' => JText::_('Creates a new post, and optionally publishes it in frontpage.'),
				'signature' => array(array($xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcInt, $xmlrpcInt, $xmlrpcBoolean))
			),
				'blogger.getPost' => array(
				'function' => 'plgXMLRPCBloggerServices::getPost',
				'docstring' => JText::_('Returns information about a specific post.'),
				'signature' => array(array($xmlrpcStruct, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString))
			),
				'joooid.getRecentPosts' => array(
				'function' => 'plgXMLRPCJoooidServices::getRecentPosts',
				'docstring' => JText::_('Returns a list of the most recent posts in the system.'),
				'signature' => array(array($xmlrpcArray, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcInt))
			),
				'joooid.trashPost' => array(
				'function' => 'plgXMLRPCJoooidServices::trashPost',
				'docstring' => JText::_('Trash a post.'),
				'signature' => array(array($xmlrpcBoolean, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcBoolean))
			),
				'joooid.publishPost' => array(
				'function' => 'plgXMLRPCJoooidServices::publishPost',
				'docstring' => JText::_('Restore a post.'),
				'signature' => array(array($xmlrpcBoolean, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcBoolean))
			),
				'joooid.unpublishPost' => array(
				'function' => 'plgXMLRPCJoooidServices::unpublishPost',
				'docstring' => JText::_('Restore a post.'),
				'signature' => array(array($xmlrpcBoolean, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcBoolean))
			),
				'joooid.version' => array(
				'function' => 'plgXMLRPCJoooidServices::getJoomlaVersion',
				'docstring' => JText::_('Get Joomla version.'),
				'signature' => array(array($xmlrpcString))
			)
		);
	}
}

class plgXMLRPCJoooidServices
{

function getUserInfo($appkey, $username, $password)
	{
		global $xmlrpcerruser, $xmlrpcStruct;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		$struct = new xmlrpcval(
		array(
			'nickname'	=> new xmlrpcval($user->get('username')),
			'userid'	=> new xmlrpcval($user->get('id')),
			'url'		=> new xmlrpcval(''),
			'email'		=> new xmlrpcval($user->get('email')),
			'lastname'	=> new xmlrpcval($user->get('name')),
			'firstname'	=> new xmlrpcval($user->get('name'))
		), $xmlrpcStruct);

		return new xmlrpcresp($struct);
	}


	  function getUserBlogs($appkey, $username, $password)
	{
		global $mainframe, $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		// Handle the access permissions part of the main database query
		if ($user->authorize('com_content', 'edit', 'content', 'all')) {
			$xwhere = '';
		} else {
			$xwhere = ' AND a.published = 1 AND b.published = 1';
		}
		$gid		= $user->get('aid', 0);
		$access_check = ' AND a.access <= '.(int) $gid .
						' AND b.access <= '.(int) $gid;
		// Query of categories within section
		$query = 'SELECT a.id, a.title, a.alias, a.section, b.title AS catsection, a.access, a.published, a.checked_out_time' .
				' FROM #__categories AS a' .
				' LEFT JOIN #__sections AS b ON a.section = b.id' .
				$xwhere.
				$access_check;
		$db = &JFactory::getDBO();
		$db->setQuery( $query );
		$categories = $db->loadObjectList();
		$structarray = array();

		foreach( $categories AS $category ) {
			if (intval($category->section) > 0) {
				$blog = new xmlrpcval(array(
					'id'		=> new xmlrpcval($category->id, $xmlrpcString),
					'title'		=> new xmlrpcval($category->title, $xmlrpcString),
					'alias'		=> new xmlrpcval($category->alias, $xmlrpcString),
					'date'		=> new xmlrpcval($category->checked_out_time, $xmlrpcString),
					'section'	=> new xmlrpcval($category->catsection, $xmlrpcString),
					'access'	=> new xmlrpcval($category->access, $xmlrpcString),
					'published'	=> new xmlrpcval($category->published, $xmlrpcString)
					), 'struct');
				array_push($structarray, $blog);
			}
		}
		return new xmlrpcresp(new xmlrpcval( $structarray , $xmlrpcArray));
	}
	
	function getPost($appkey, $postid, $username, $password)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		$db = &JFactory::getDBO();

		$where = 'a.id = ' . (int) $postid;

		$canReadUnpublished = $user->authorize('com_content', 'edit', 'content', 'all');
		if ($canReadUnpublished) {
			$publishedWhere = '';
		} else {
			$publishedWhere = ' AND u.published = 1 AND b.published = 1';
		}

		$nullDate 		= $db->getNullDate();
		$date =& JFactory::getDate();
		$now = $date->toMySQL();

		$query = 'SELECT a.title AS title,'
		. ' a.created AS created,'
		. ' a.introtext AS description,'
		. ' a.fulltext AS text_more,'
		. ' a.id AS id,'
		. ' a.alias AS alias,'
		. ' a.state AS state,'
		. ' a.published AS published,'
		. ' a.created_by AS created_by'
		. ' FROM #__content AS a'
		. ' INNER JOIN #__categories AS b ON b.id=a.catid'
		. ' INNER JOIN #__sections AS u ON u.id = a.sectionid'
		. ' WHERE '.$where
		. $publishedWhere
		. ' AND a.access <= '.(int) $user->get( 'aid' )
		. ' AND b.access <= '.(int) $user->get( 'aid' )
		. ' AND u.access <= '.(int) $user->get( 'aid' )
		. ' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )'
		. ' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )'
		;

		$db->setQuery( $query );
		$item = $db->loadObject();

		if ($item === null) {
			return new xmlrpcresp(0, $xmlrpcerruser+2, JText::_("Access Denied"));
		}

		
		$struct = new xmlrpcval(
		array(
			'userid'		=> new xmlrpcval($item->created_by),
			'postid'		=> new xmlrpcval($item->id),
			'title'			=> new xmlrpcval($item->title),
			'alias'			=> new xmlrpcval($item->alias),
			'description'		=> new xmlrpcval($item->description),
			'text_more'		=> new xmlrpcval($item->text_more),
			'date'			=> new xmlrpcval($item->created),
			'state'			=> new xmlrpcval($item->state),
			'access'		=> new xmlrpcval($item->published)
		), $xmlrpcStruct);

		return new xmlrpcresp($struct);
	}

	function newPost($appkey, $blogid, $username, $password, $title, $introtext, $fulltext, $state, $accessval, $frontpage)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		if ($user->get('gid') < 19) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('ALERTNOTAUTH'));
		}

		// Create a user access object for the user
		$access				= new stdClass();
		$access->canEdit		= $user->authorize('com_content', 'edit', 'content', 'all');
		$access->canEditOwn		= $user->authorize('com_content', 'edit', 'content', 'own');
		$access->canPublish		= $user->authorize('com_content', 'publish', 'content', 'all');

		if (!($access->canEdit || $access->canEditOwn)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('ALERTNOTAUTH'));
		}

		$db =& JFactory::getDBO();

		// load plugin params info
	 	$plugin =& JPluginHelper::getPlugin('xmlrpc','blogger');
	 	$params = new JParameter( $plugin->params );

		$blogid = (int) $blogid;

		// load the category
		$cat =& JTable::getInstance('category');
		$cat->load($blogid);

		// create a new content item
		$item =& JTable::getInstance('content');

		$item->title	 	= $title;
		$item->introtext	= $introtext;
		$item->fulltext		= $fulltext;

		$item->catid	 	= $blogid;
		$item->sectionid 	= $cat->section;

		$date =& JFactory::getDate();

		$item->created		= $date->toMySQL();
		$item->created_by	= $user->get('id');

		$item->publish_up	= $date->toMySQL();
		$item->publish_down	= $db->getNullDate();
		

		if (!$access->canPublish && $state == 1) $item->state = 0;
		else $item->state = $state;

		$item->access = $accessval;

		if (!$item->check()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post check failed') );
		}

		$item->version++;

		if (!$item->store()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post store failed') );
		}
		
		plgXMLRPCJoooidHelper::updateFrontPage($item->id, $frontpage);

		return new xmlrpcresp(new xmlrpcval($item->id, $xmlrpcString));
	}

	function editPost($appkey, $postid, $username, $password, $title, $introtext, $fulltext, $state, $accessval, $frontpage)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		// Create a user access object for the user
		$access					= new stdClass();
		$access->canEdit		= $user->authorize('com_content', 'edit', 'content', 'all');
		$access->canEditOwn		= $user->authorize('com_content', 'edit', 'content', 'own');
		$access->canPublish		= $user->authorize('com_content', 'publish', 'content', 'all');

		if (!($access->canEdit || $access->canEditOwn)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('ALERTNOTAUTH'));
		}

		// load the row from the db table
		$item =& JTable::getInstance('content');
		if(!$item->load( $postid )) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, no such post') );
		}

		if($item->isCheckedOut($user->get('id'))) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, post is already being edited') );
		}

		//lock the item
		$item->checkout($user->id);

		$item->title	 	= $title;
		$item->introtext	= $introtext;
		$item->fulltext		= $fulltext;

		if (!$access->canPublish && $state == 1) $item->state = 0;
		else $item->state = $state;

		$item->access = $accessval;

		 plgXMLRPCJoooidHelper::updateFrontPage($item->id, $frontpage);

		if (!$item->check()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post check failed') );
		}

		$item->version++;

		if (!$item->store()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post store failed') );
		}

		return new xmlrpcresp(new xmlrpcval('true', $xmlrpcString));
	}

	function uploadFile($username, $password, $folder = '', $data) {
		global $xmlrpcerruser;
		
		$result = "true";

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}


			$name = $data['name'];

			$bits = $data['bits'];			
			$bits = base64_decode($bits);
			if (isset($name)) {

					jimport('joomla.filesystem.file');
					jimport('joomla.filesystem.path');
					jimport('joomla.filesystem.folder');
					
					$folderpath = JPath::clean(JPATH_ROOT.$folder);
					$filepath = JPath::clean( $folderpath.DS.strtolower($name) );
					
					$err = ""; 

					if ( !JFolder::create($folderpath) ) {				
						return new xmlrpcresp(0, $xmlrpcerruser+3, "error create folder: ".$folderpath );
					}
					
					if( !JFile::write($filepath, $bits) ) {
						return new xmlrpcresp(0, $xmlrpcerruser+3, "error create File: ".$filepath );
					} 
		        }				

		return new xmlrpcresp(new xmlrpcval($result));
	}

	function uploadImage($username, $password, $folder = '', $data) {
		global $xmlrpcerruser;
		
		$result = "true";

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

					
			$name = $data['name'];

			$bits = $data['bits'];			
			$bits = base64_decode($bits);
			if (isset($name)) {

					jimport('joomla.filesystem.file');
					jimport('joomla.filesystem.path');
					jimport('joomla.filesystem.folder');
					
					$folderpath = JPath::clean(JPATH_ROOT.$folder);
					$filepath = JPath::clean( $folderpath.DS.strtolower($name) );
					
					$err = ""; 
								
					//exists dir?
					if ( !JFolder::create($folderpath) ) {				
						return new xmlrpcresp(0, $xmlrpcerruser+3, "error create folder: ".$folderpath );
					}
					
					//write stream to file
					if( !JFile::write($filepath, $bits) ) {
						return new xmlrpcresp(0, $xmlrpcerruser+3, "error create File: ".$filepath );
					} 
		        }				

		return new xmlrpcresp(new xmlrpcval($result));
	}

	function getRecentPosts($appkey, $blogid, $username, $password, $numposts)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		$db =& JFactory::getDBO();

		$nullDate 		= $db->getNullDate();
		$date =& JFactory::getDate();
		$now = $date->toMySQL();

		$blogid = (int) $blogid;

		$canReadUnpublished = $user->authorize('com_content', 'edit', 'content', 'all');
		if ($canReadUnpublished) {
			$publishedWhere = '';
			$publishTimeWhere = '';
		} else {
			$publishedWhere = ' AND u.published = 1 AND b.published = 1';
			$publishTimeWhere = ' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )'
			. ' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )';
		}
		if ($blogid == "0"){
		$query = 'SELECT a.title AS title,'
		. ' a.created AS created,'
		. ' a.introtext AS description,'
		. ' a.fulltext AS text_more,'
		. ' a.id AS id,'
		. ' a.alias AS alias,'
		. ' a.state AS state,'
		. ' a.access AS published,'
		. ' a.created_by AS created_by'
		. ' WHERE a.catid = '. $blogid
		. $publishedWhere
		. ' AND a.access <= '.(int) $user->get( 'aid' )
		. $publishTimeWhere
		. ' ORDER BY id DESC'
		;		

		} else {
		
		$query = 'SELECT a.title AS title,'
		. ' a.created AS created,'
		. ' a.introtext AS description,'
		. ' a.fulltext AS text_more,'
		. ' a.id AS id,'
		. ' a.alias AS alias,'
		. ' a.state AS state,'
		. ' a.access AS published,'
		. ' a.created_by AS created_by'
		. ' FROM #__content AS a'
		. ' INNER JOIN #__categories AS b ON b.id = a.catid'
		. ' INNER JOIN #__sections AS u ON u.id = a.sectionid'
		. ' WHERE a.catid = '. $blogid
		. $publishedWhere
		. ' AND a.access <= '.(int) $user->get( 'aid' )
		. ' AND b.access <= '.(int) $user->get( 'aid' )
		. ' AND u.access <= '.(int) $user->get( 'aid' )
		. $publishTimeWhere
		. ' ORDER BY id DESC'
		;
	        }

		$db->setQuery($query, 0, $numposts);
		$items = $db->loadObjectList();

		if ($items === null) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('No posts available, or an error has occured.') );
		}

		$structArray = array();
		foreach ($items as $item)
		{
			$structArray[] = new xmlrpcval(array(
				'userid'		=> new xmlrpcval($item->created_by),
				'postid'		=> new xmlrpcval($item->id),
				'title'			=> new xmlrpcval($item->title),
				'alias'			=> new xmlrpcval($item->alias),
				'description'		=> new xmlrpcval($item->description),
				'text_more'		=> new xmlrpcval($item->text_more),
				'date'			=> new xmlrpcval($item->created),
				'state'			=> new xmlrpcval($item->state),
				'access'		=> new xmlrpcval($item->published)
			), 'struct');
		}

		return new xmlrpcresp(new xmlrpcval( $structArray , $xmlrpcArray));
	}

	function trashPost($appkey, $postid, $username, $password, $publish)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		if ($user->get('gid') < 23) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('ALERTNOTAUTH'));
		}

		// load the row from the db table
		$item =& JTable::getInstance('content');
		if(!$item->load( $postid )) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, no such post') );
		}

		if($item->isCheckedOut($user->get('id'))) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, post is already being edited') );
		}

		$item->checkout($user->id);

		$item->state = -2;
		$item->ordering = 0;

		if (!$item->store()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post delete failed') );
		}

		return new xmlrpcresp(new xmlrpcval('true', $xmlrpcBoolean));
	}

	function publishPost($appkey, $postid, $username, $password, $publish)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		if ($user->get('gid') < 23) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('ALERTNOTAUTH'));
		}

		// load the row from the db table
		$item =& JTable::getInstance('content');
		if(!$item->load( $postid )) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, no such post') );
		}

		if($item->isCheckedOut($user->get('id'))) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, post is already being edited') );
		}

		//lock the item
		$item->checkout($user->id);

		$item->state = 1;
		$item->ordering = 0;

		if (!$item->store()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post delete failed') );
		}

		return new xmlrpcresp(new xmlrpcval('true', $xmlrpcBoolean));
	}

	function unpublishPost($appkey, $postid, $username, $password, $publish)
	{
		global $xmlrpcerruser, $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

		if(!plgXMLRPCJoooidHelper::authenticateUser($username, $password)) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_("Login Failed"));
		}

		$user =& JFactory::getUser($username);
		plgXMLRPCJoooidHelper::getUserAid( $user );

		if ($user->get('gid') < 23) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('ALERTNOTAUTH'));
		}

		// load the row from the db table
		$item =& JTable::getInstance('content');
		if(!$item->load( $postid )) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, no such post') );
		}

		if($item->isCheckedOut($user->get('id'))) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Sorry, post is already being edited') );
		}

		//lock the item
		$item->checkout($user->id);

		$item->state = 0;
		$item->ordering = 0;

		if (!$item->store()) {
			return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Post delete failed') );
		}

		return new xmlrpcresp(new xmlrpcval('true', $xmlrpcBoolean));
	}


	function getTemplate($appkey, $blogid, $username, $password, $templateType)
	{
		global $xmlrpcerruser;
		return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Method not implemented') );
	}

	function setTemplate($appkey, $blogid, $username, $password, $template, $templateType)
	{
		global $xmlrpcerruser;
		return new xmlrpcresp(0, $xmlrpcerruser+1, JText::_('Method not implemented') );
	}

	function getJoomlaVersion() {
		jimport( 'joomla.version' );
		$joomlaver = new JVersion();
		return $joomlaver->getShortVersion();
	}
 
}

class plgXMLRPCJoooidHelper
{

function updateFrontPage($id, $frontpage)
	{
		$db = &JFactory::getDBO();

		require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_frontpage'.DS.'tables'.DS.'frontpage.php');
		$fp = new TableFrontPage($db);

		// Is the article viewable on the frontpage?
		if ($frontpage)
		{
			// Is the item already viewable on the frontpage?
			if (!$fp->load($id))
			{
				// Insert the new entry
				$query = 'INSERT INTO #__content_frontpage' .
				' VALUES ( '. (int) $id .', 1 )';
				$db->setQuery($query);
				if (!$db->query())
				{
					return false;
				}
				$fp->ordering = 1;
			}
		}
		else
		{
			// Delete the item from frontpage if it exists
			if (!$fp->delete($id)) {
				return false;
			}
			$fp->ordering = 0;
		}
		$fp->reorder();
	}

function getUserAid( &$user ) {

		$acl = &JFactory::getACL();

		//Get the user group from the ACL
		$grp = $acl->getAroGroup($user->get('id'));

		// Mark the user as logged in
		$user->set('guest', 0);
		$user->set('aid', 1);

		// Fudge Authors, Editors, Publishers and Super Administrators into the special access group
		if ($acl->is_group_child_of($grp->name, 'Registered')      ||
			$acl->is_group_child_of($grp->name, 'Public Backend')) {
 			$user->set('aid', 2);
 		}
	}

	function authenticateUser($username, $password)
	{
		// Get the global JAuthentication object
		jimport( 'joomla.user.authentication');
		$auth = & JAuthentication::getInstance();
		$credentials = array( 'username' => $username, 'password' => $password );
		$options = array();
		$response = $auth->authenticate($credentials, $options);
		return $response->status === JAUTHENTICATE_STATUS_SUCCESS;
	}

	function getPostTitle($content)
	{
		$title = '';
		if ( preg_match('/<title>(.+?)<\/title>/is', $content, $matchtitle) )
		{
			$title = $matchtitle[0];
			$title = preg_replace('/<title>/si', '', $title);
			$title = preg_replace('/<\/title>/si', '', $title);
		}
		if (empty( $title )) {
			$title = substr( $content, 0, 20 );
		}
		return $title;
	}

	function getPostCategory($content)
	{
		$category = 0;

		$match = array();
		if ( preg_match('/<category>(.+?)<\/category>/is', $content, $match) )
		{
			$category = trim($match[1], ',');
			$category = explode(',', $category);
		}

		return $category;
	}

	function getPostIntroText($content)
	{
		return plgXMLRPCJoooidHelper::removePostData($content); //substr($string, 0, strpos($string, '<more_text>'));
	}

	function getPostFullText($content)
	{
		$match = array();
		if ( preg_match('/<more_text>(.+?)<\/more_text>/is', $content, $match) )
		{
			$fulltext = $match[0];
			$fulltext = preg_replace('/<more_text>/si', '', $fulltext);
			$fulltext = preg_replace('/<\/more_text>/si', '', $fulltext);
		}

		return $fulltext;
	}

	function removePostData($content)
	{
		$content = preg_replace('/<title>(.+?)<\/title>/si', '', $content);
		$content = preg_replace('/<category>(.+?)<\/category>/si', '', $content);
		$content = preg_replace('/<more_text>(.+?)<\/more_text>/si', '', $content);
		$content = trim($content);
		return $content;
	}
	
}


